package com.NeoBank.Funds_Transfer_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundsTransferServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

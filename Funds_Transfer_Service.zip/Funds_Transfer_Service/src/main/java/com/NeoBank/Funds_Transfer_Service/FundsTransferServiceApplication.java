package com.NeoBank.Funds_Transfer_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundsTransferServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundsTransferServiceApplication.class, args);
	}

}

package com.NeoBank.Funds_Transfer_Service.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.NeoBank.Funds_Transfer_Service.Model.FundsTransferModel;
import com.NeoBank.Funds_Transfer_Service.Service.FundsTransferService;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/funds")
public class FundsTransferController {

    @Autowired
    private FundsTransferService service;

    // Initiate fund transfer
    @PostMapping("/transfer")
    public ResponseEntity<Map<String, Object>> initiateTransfer(
            @RequestParam String sourceAccountNo,
            @RequestParam String targetAccountNo,
            @RequestParam BigDecimal amount,
            @RequestParam String paymentMethod) {
        
        try {
            FundsTransferModel result = service.initiateTransfer(sourceAccountNo, targetAccountNo, amount, paymentMethod);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Transfer initiated successfully");
            response.put("transactionId", result.getTransactionId());
            response.put("status", result.getStatus());
            response.put("data", result);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return buildErrorResponse(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return buildErrorResponse("Transfer failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Verify transaction status
    @GetMapping("/verifyStatus")
    public ResponseEntity<Map<String, Object>> verifyStatus(@RequestParam String transactionId) {
        try {
            FundsTransferModel result = service.verifyStatus(transactionId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("transactionId", result.getTransactionId());
            response.put("status", result.getStatus());
            response.put("data", result);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return buildErrorResponse(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return buildErrorResponse("Status verification failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Schedule fund transfer
    @PostMapping("/schedule")
    public ResponseEntity<Map<String, Object>> scheduleTransfer(
            @RequestParam String sourceAccountNo,
            @RequestParam String targetAccountNo,
            @RequestParam BigDecimal amount,
            @RequestParam String paymentMethod,
            @RequestParam String scheduledTime) {
        
        try {
            FundsTransferModel result = service.scheduleTransfer(sourceAccountNo, targetAccountNo, amount, paymentMethod, scheduledTime);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Transfer scheduled successfully");
            response.put("transactionId", result.getTransactionId());
            response.put("scheduledTime", result.getScheduledTime());
            response.put("status", result.getStatus());
            response.put("data", result);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return buildErrorResponse(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return buildErrorResponse("Scheduling failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Cancel transfer
    @PutMapping("/cancel")
    public ResponseEntity<Map<String, Object>> cancelTransfer(@RequestParam String transactionId) {
        try {
            String message = service.cancelTransfer(transactionId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", message);
            response.put("transactionId", transactionId);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return buildErrorResponse(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (IllegalStateException e) {
            return buildErrorResponse(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return buildErrorResponse("Cancellation failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Helper method to build error responses
    private ResponseEntity<Map<String, Object>> buildErrorResponse(String message, HttpStatus status) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return ResponseEntity.status(status).body(response);
    }
}
package com.NeoBank.Funds_Transfer_Service.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.NeoBank.Funds_Transfer_Service.Model.FundsTransferModel;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class FundsTransferDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String INSERT_TRANSFER = 
        "INSERT INTO FundsTransfer (transactionId, sourceAccountNo, targetAccountNo, amount, paymentMethod, status, scheduledTime, createdAt, updatedAt) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_STATUS = 
        "UPDATE FundsTransfer SET status = ?, updatedAt = ? WHERE transactionId = ?";

    private static final String GET_BY_TRANSACTION_ID = 
        "SELECT * FROM FundsTransfer WHERE transactionId = ?";

    private static final String GET_SCHEDULED_TRANSFERS = 
        "SELECT * FROM FundsTransfer WHERE status = 'Pending' AND scheduledTime <= ? AND scheduledTime IS NOT NULL";

    private static final String CANCEL_TRANSFER = 
        "UPDATE FundsTransfer SET status = 'Cancelled', updatedAt = ? WHERE transactionId = ? AND status IN ('Pending', 'Scheduled')";

    // Insert new transfer
    public int insertTransfer(FundsTransferModel model) {
        return jdbcTemplate.update(INSERT_TRANSFER,
                model.getTransactionId(),
                model.getSourceAccountNo(),
                model.getTargetAccountNo(),
                model.getAmount(),
                model.getPaymentMethod(),
                model.getStatus(),
                model.getScheduledTime(),
                Timestamp.valueOf(LocalDateTime.now()),
                Timestamp.valueOf(LocalDateTime.now()));
    }

    // Update transfer status
    public int updateStatus(String transactionId, String status) {
        return jdbcTemplate.update(UPDATE_STATUS, status, Timestamp.valueOf(LocalDateTime.now()), transactionId);
    }

    // Get transfer by transaction ID
    public FundsTransferModel getByTransactionId(String transactionId) {
        try {
            return jdbcTemplate.queryForObject(GET_BY_TRANSACTION_ID, new FundsTransferRowMapper(), transactionId);
        } catch (Exception e) {
            return null;
        }
    }

    // Get scheduled transfers that are due
    public List<FundsTransferModel> getScheduledTransfersDue() {
        return jdbcTemplate.query(GET_SCHEDULED_TRANSFERS, new FundsTransferRowMapper(), Timestamp.valueOf(LocalDateTime.now()));
    }

    // Cancel transfer
    public int cancelTransfer(String transactionId) {
        return jdbcTemplate.update(CANCEL_TRANSFER, Timestamp.valueOf(LocalDateTime.now()), transactionId);
    }

    // Check if account exists (mock validation)
    public boolean accountExists(String accountNo) {
        // In a real application, this would query an Accounts table
        // For now, returning true if account number is valid format
        return accountNo != null && accountNo.matches("\\d{10,16}");
    }

    // RowMapper for FundsTransferModel
    private static class FundsTransferRowMapper implements RowMapper<FundsTransferModel> {
        @Override
        public FundsTransferModel mapRow(ResultSet rs, int rowNum) throws SQLException {
            FundsTransferModel model = new FundsTransferModel();
            model.setTransactionId(rs.getString("transactionId"));
            model.setSourceAccountNo(rs.getString("sourceAccountNo"));
            model.setTargetAccountNo(rs.getString("targetAccountNo"));
            model.setAmount(rs.getBigDecimal("amount"));
            model.setPaymentMethod(rs.getString("paymentMethod"));
            model.setStatus(rs.getString("status"));
            
            Timestamp scheduledTime = rs.getTimestamp("scheduledTime");
            if (scheduledTime != null) {
                model.setScheduledTime(scheduledTime.toLocalDateTime());
            }
            
            model.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
            model.setUpdatedAt(rs.getTimestamp("updatedAt").toLocalDateTime());
            
            return model;
        }
    }
}
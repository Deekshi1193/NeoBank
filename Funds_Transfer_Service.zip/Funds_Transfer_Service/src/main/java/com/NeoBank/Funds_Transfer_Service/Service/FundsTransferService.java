package com.NeoBank.Funds_Transfer_Service.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.NeoBank.Funds_Transfer_Service.Dao.FundsTransferDao;
import com.NeoBank.Funds_Transfer_Service.Model.FundsTransferModel;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
public class FundsTransferService {

    @Autowired
    private FundsTransferDao dao;

    private static final List<String> VALID_PAYMENT_METHODS = Arrays.asList("NEFT", "IMPS", "RTGS");
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

    public FundsTransferModel initiateTransfer(String sourceAccountNo, String targetAccountNo,
                                               BigDecimal amount, String paymentMethod) {
        validateTransferRequest(sourceAccountNo, targetAccountNo, amount, paymentMethod);

        String transactionId = generateTransactionId();

        FundsTransferModel model = new FundsTransferModel();
        model.setTransactionId(transactionId);
        model.setSourceAccountNo(sourceAccountNo);
        model.setTargetAccountNo(targetAccountNo);
        model.setAmount(amount);
        model.setPaymentMethod(paymentMethod.toUpperCase());
        model.setStatus("Pending");

        dao.insertTransfer(model);
        processTransfer(transactionId);

        return dao.getByTransactionId(transactionId);
    }

    public FundsTransferModel scheduleTransfer(String sourceAccountNo, String targetAccountNo,
                                               BigDecimal amount, String paymentMethod, String scheduledTime) {
        validateTransferRequest(sourceAccountNo, targetAccountNo, amount, paymentMethod);

        LocalDateTime scheduledDateTime;
        try {
            scheduledDateTime = LocalDateTime.parse(scheduledTime, FORMATTER);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid scheduledTime format. Use yyyy-MM-dd'T'HH:mm:ss");
        }

        if (scheduledDateTime.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Scheduled time must be in the future");
        }

        String transactionId = generateTransactionId();

        FundsTransferModel model = new FundsTransferModel();
        model.setTransactionId(transactionId);
        model.setSourceAccountNo(sourceAccountNo);
        model.setTargetAccountNo(targetAccountNo);
        model.setAmount(amount);
        model.setPaymentMethod(paymentMethod.toUpperCase());
        model.setStatus("Scheduled");
        model.setScheduledTime(scheduledDateTime);

        dao.insertTransfer(model);
        return dao.getByTransactionId(transactionId);
    }

    public FundsTransferModel verifyStatus(String transactionId) {
        FundsTransferModel model = dao.getByTransactionId(transactionId);
        if (model == null) {
            throw new IllegalArgumentException("Transaction ID not found: " + transactionId);
        }
        return model;
    }

    public String cancelTransfer(String transactionId) {
        FundsTransferModel model = dao.getByTransactionId(transactionId);
        if (model == null) {
            throw new IllegalArgumentException("Transaction ID not found: " + transactionId);
        }

        if (!"Pending".equals(model.getStatus()) && !"Scheduled".equals(model.getStatus())) {
            throw new IllegalStateException("Cannot cancel transfer with status: " + model.getStatus());
        }

        int updated = dao.cancelTransfer(transactionId);
        if (updated > 0) {
            return "Transfer cancelled successfully";
        } else {
            throw new IllegalStateException("Failed to cancel transfer");
        }
    }

    @Scheduled(fixedRate = 60000)
    public void processScheduledTransfers() {
        List<FundsTransferModel> dueTransfers = dao.getScheduledTransfersDue();
        for (FundsTransferModel transfer : dueTransfers) {
            processTransfer(transfer.getTransactionId());
        }
    }

    private void processTransfer(String transactionId) {
        try {
            Thread.sleep(1000);
            dao.updateStatus(transactionId, "Completed");
        } catch (Exception e) {
            dao.updateStatus(transactionId, "Failed");
        }
    }

    private String generateTransactionId() {
        return "TXN" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private void validateTransferRequest(String sourceAccountNo, String targetAccountNo,
                                         BigDecimal amount, String paymentMethod) {
        if (sourceAccountNo == null || sourceAccountNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Source account number is required");
        }
        if (targetAccountNo == null || targetAccountNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Target account number is required");
        }
        if (sourceAccountNo.equals(targetAccountNo)) {
            throw new IllegalArgumentException("Source and target accounts cannot be the same");
        }
        if (!dao.accountExists(sourceAccountNo)) {
            throw new IllegalArgumentException("Invalid source account number");
        }
        if (!dao.accountExists(targetAccountNo)) {
            throw new IllegalArgumentException("Invalid target account number");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero");
        }
        if (amount.compareTo(new BigDecimal("1000000")) > 0) {
            throw new IllegalArgumentException("Amount exceeds maximum transfer limit");
        }
        if (paymentMethod == null || !VALID_PAYMENT_METHODS.contains(paymentMethod.toUpperCase())) {
            throw new IllegalArgumentException("Invalid payment method. Use NEFT, IMPS, or RTGS");
        }
    }
}
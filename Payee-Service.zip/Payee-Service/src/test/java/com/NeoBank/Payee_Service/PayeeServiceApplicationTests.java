package com.NeoBank.Payee_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

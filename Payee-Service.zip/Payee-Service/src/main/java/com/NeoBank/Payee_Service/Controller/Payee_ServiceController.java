package com.NeoBank.Payee_Service.Controller;

import com.NeoBank.Payee_Service.Model.Payee_Service;
import com.NeoBank.Payee_Service.Model.Payee_ServiceDto;
import com.NeoBank.Payee_Service.Service.Payee_ServiceService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payees")
public class Payee_ServiceController {
    
    private static final Logger log = LoggerFactory.getLogger(Payee_ServiceController.class);
    
    private final Payee_ServiceService payeeServiceService;
    
    @Autowired
    public Payee_ServiceController(Payee_ServiceService payeeServiceService) {
        this.payeeServiceService = payeeServiceService;
    }
    
    /**
     * Add a new payee
     * POST /api/payees/addPayee
     */
    @PostMapping("/addPayee")
    public ResponseEntity<Map<String, Object>> addPayee(@Valid @RequestBody Payee_ServiceDto payeeServiceDto) {
        log.info("Received request to add payee: {}", payeeServiceDto.getPayeeName());
        
        Payee_Service createdPayee = payeeServiceService.addPayee(payeeServiceDto);
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Payee added successfully");
        response.put("data", createdPayee);
        
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    /**
     * Delete payee by account ID
     * DELETE /api/payees/deleteByAccountId/{id}
     */
    @DeleteMapping("/deleteByAccountId/{id}")
    public ResponseEntity<Map<String, String>> deleteByAccountId(@PathVariable("id") Long payeeAccountId) {
        log.info("Received request to delete payee by ID: {}", payeeAccountId);
        
        String message = payeeServiceService.deleteByAccountId(payeeAccountId);
        
        Map<String, String> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", message);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Delete payee by name
     * DELETE /api/payees/deleteByName/{name}
     */
    @DeleteMapping("/deleteByName/{name}")
    public ResponseEntity<Map<String, String>> deleteByName(@PathVariable("name") String payeeName) {
        log.info("Received request to delete payee by name: {}", payeeName);
        
        String message = payeeServiceService.deleteByName(payeeName);
        
        Map<String, String> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", message);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Search payee by account ID
     * GET /api/payees/searchById/{id}
     */
    @GetMapping("/searchById/{id}")
    public ResponseEntity<Map<String, Object>> searchById(@PathVariable("id") Long payeeAccountId) {
        log.info("Received request to search payee by ID: {}", payeeAccountId);
        
        Payee_Service payee = payeeServiceService.searchById(payeeAccountId);
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("data", payee);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Search payees by name
     * GET /api/payees/searchByName/{name}
     */
    @GetMapping("/searchByName/{name}")
    public ResponseEntity<Map<String, Object>> searchByName(@PathVariable("name") String payeeName) {
        log.info("Received request to search payees by name: {}", payeeName);
        
        List<Payee_Service> payees = payeeServiceService.searchByName(payeeName);
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("count", payees.size());
        response.put("data", payees);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Search payees by IFSC code
     * GET /api/payees/searchByIFSC/{ifsc}
     */
    @GetMapping("/searchByIFSC/{ifsc}")
    public ResponseEntity<Map<String, Object>> searchByIFSC(@PathVariable("ifsc") String ifscCode) {
        log.info("Received request to search payees by IFSC: {}", ifscCode);
        
        List<Payee_Service> payees = payeeServiceService.searchByIFSC(ifscCode);
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("count", payees.size());
        response.put("data", payees);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Search payees by bank name
     * GET /api/payees/searchByBankName/{bank}
     */
    @GetMapping("/searchByBankName/{bank}")
    public ResponseEntity<Map<String, Object>> searchByBankName(@PathVariable("bank") String bankName) {
        log.info("Received request to search payees by bank name: {}", bankName);
        
        List<Payee_Service> payees = payeeServiceService.searchByBankName(bankName);
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("count", payees.size());
        response.put("data", payees);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Update payee by account ID
     * PUT /api/payees/updateById/{id}
     */
    @PutMapping("/updateById/{id}")
    public ResponseEntity<Map<String, Object>> updateById(
            @PathVariable("id") Long payeeAccountId,
            @Valid @RequestBody Payee_ServiceDto payeeServiceDto) {
        log.info("Received request to update payee with ID: {}", payeeAccountId);
        
        Payee_Service updatedPayee = payeeServiceService.updateById(payeeAccountId, payeeServiceDto);
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Payee updated successfully");
        response.put("data", updatedPayee);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Get all payees (Additional endpoint)
     * GET /api/payees/all
     */
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllPayees() {
        log.info("Received request to fetch all payees");
        
        List<Payee_Service> payees = payeeServiceService.getAllPayees();
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("count", payees.size());
        response.put("data", payees);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
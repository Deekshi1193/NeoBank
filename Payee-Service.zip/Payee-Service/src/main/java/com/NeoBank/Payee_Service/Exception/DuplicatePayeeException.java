package com.NeoBank.Payee_Service.Exception;

// DuplicatePayeeException.java
public class DuplicatePayeeException extends RuntimeException {
    public DuplicatePayeeException(String message) {
        super(message);
    }
}

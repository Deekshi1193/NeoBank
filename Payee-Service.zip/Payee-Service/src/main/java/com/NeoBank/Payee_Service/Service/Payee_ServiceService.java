package com.NeoBank.Payee_Service.Service;

import com.NeoBank.Payee_Service.Dao.Payee_ServiceDao;
import com.NeoBank.Payee_Service.Exception.PayeeNotFoundException;
import com.NeoBank.Payee_Service.Model.Payee_Service;
import com.NeoBank.Payee_Service.Model.Payee_ServiceDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Payee_ServiceService {
    
    private static final Logger log = LoggerFactory.getLogger(Payee_ServiceService.class);
    
    private final Payee_ServiceDao payeeServiceDao;
    
    @Autowired
    public Payee_ServiceService(Payee_ServiceDao payeeServiceDao) {
        this.payeeServiceDao = payeeServiceDao;
    }
    
    /**
     * Add a new payee
     */
    public Payee_Service addPayee(Payee_ServiceDto payeeServiceDto) {
        log.info("Adding new payee: {}", payeeServiceDto.getPayeeName());
        
        // Create new Payee_Service entity
        Payee_Service payeeService = new Payee_Service();
        payeeService.setPayeeName(payeeServiceDto.getPayeeName());
        payeeService.setPayeeBankName(payeeServiceDto.getPayeeBankName());
        payeeService.setIfscCode(payeeServiceDto.getIfscCode().toUpperCase());
        payeeService.setBranchAddress(payeeServiceDto.getBranchAddress());
        
        // Save to database
        Payee_Service savedPayee = payeeServiceDao.save(payeeService);
        log.info("Payee added successfully with ID: {}", savedPayee.getPayeeAccountId());
        
        return savedPayee;
    }
    
    /**
     * Delete payee by account ID
     */
    public String deleteByAccountId(Long payeeAccountId) {
        log.info("Deleting payee with account ID: {}", payeeAccountId);
        
        // Check if payee exists
        if (!payeeServiceDao.existsByPayeeAccountId(payeeAccountId)) {
            log.error("Payee not found with ID: {}", payeeAccountId);
            throw new PayeeNotFoundException("Payee not found with account ID: " + payeeAccountId);
        }
        
        // Delete payee
        payeeServiceDao.deleteByPayeeAccountId(payeeAccountId);
        log.info("Payee deleted successfully with ID: {}", payeeAccountId);
        
        return "Payee with account ID " + payeeAccountId + " deleted successfully";
    }
    
    /**
     * Delete payee by name
     */
    public String deleteByName(String payeeName) {
        log.info("Deleting payee with name: {}", payeeName);
        
        // Check if payee exists
        List<Payee_Service> payees = payeeServiceDao.findByPayeeNameContainingIgnoreCase(payeeName);
        if (payees.isEmpty()) {
            log.error("No payees found with name: {}", payeeName);
            throw new PayeeNotFoundException("No payees found with name: " + payeeName);
        }
        
        // Delete payees by name
        payeeServiceDao.deleteByPayeeName(payeeName);
        log.info("Payee(s) deleted successfully with name: {}", payeeName);
        
        return "Payee(s) with name '" + payeeName + "' deleted successfully";
    }
    
    /**
     * Search payee by account ID
     */
    @Transactional(readOnly = true)
    public Payee_Service searchById(Long payeeAccountId) {
        log.info("Searching payee by ID: {}", payeeAccountId);
        
        return payeeServiceDao.findByPayeeAccountId(payeeAccountId)
                .orElseThrow(() -> {
                    log.error("Payee not found with ID: {}", payeeAccountId);
                    return new PayeeNotFoundException("Payee not found with account ID: " + payeeAccountId);
                });
    }
    
    /**
     * Search payees by name
     */
    @Transactional(readOnly = true)
    public List<Payee_Service> searchByName(String payeeName) {
        log.info("Searching payees by name: {}", payeeName);
        
        List<Payee_Service> payees = payeeServiceDao.findByPayeeNameContainingIgnoreCase(payeeName);
        
        if (payees.isEmpty()) {
            log.warn("No payees found with name: {}", payeeName);
            throw new PayeeNotFoundException("No payees found with name: " + payeeName);
        }
        
        log.info("Found {} payee(s) with name: {}", payees.size(), payeeName);
        return payees;
    }
    
    /**
     * Search payees by IFSC code
     */
    @Transactional(readOnly = true)
    public List<Payee_Service> searchByIFSC(String ifscCode) {
        log.info("Searching payees by IFSC code: {}", ifscCode);
        
        List<Payee_Service> payees = payeeServiceDao.findByIfscCode(ifscCode.toUpperCase());
        
        if (payees.isEmpty()) {
            log.warn("No payees found with IFSC code: {}", ifscCode);
            throw new PayeeNotFoundException("No payees found with IFSC code: " + ifscCode);
        }
        
        log.info("Found {} payee(s) with IFSC code: {}", payees.size(), ifscCode);
        return payees;
    }
    
    /**
     * Search payees by bank name
     */
    @Transactional(readOnly = true)
    public List<Payee_Service> searchByBankName(String bankName) {
        log.info("Searching payees by bank name: {}", bankName);
        
        List<Payee_Service> payees = payeeServiceDao.findByPayeeBankNameContainingIgnoreCase(bankName);
        
        if (payees.isEmpty()) {
            log.warn("No payees found with bank name: {}", bankName);
            throw new PayeeNotFoundException("No payees found with bank name: " + bankName);
        }
        
        log.info("Found {} payee(s) with bank name: {}", payees.size(), bankName);
        return payees;
    }
    
    /**
     * Update payee by account ID
     */
    public Payee_Service updateById(Long payeeAccountId, Payee_ServiceDto payeeServiceDto) {
        log.info("Updating payee with ID: {}", payeeAccountId);
        
        // Find existing payee
        Payee_Service existingPayee = payeeServiceDao.findByPayeeAccountId(payeeAccountId)
                .orElseThrow(() -> {
                    log.error("Payee not found with ID: {}", payeeAccountId);
                    return new PayeeNotFoundException("Payee not found with account ID: " + payeeAccountId);
                });
        
        // Update fields
        existingPayee.setPayeeName(payeeServiceDto.getPayeeName());
        existingPayee.setPayeeBankName(payeeServiceDto.getPayeeBankName());
        existingPayee.setIfscCode(payeeServiceDto.getIfscCode().toUpperCase());
        existingPayee.setBranchAddress(payeeServiceDto.getBranchAddress());
        
        // Save updated payee
        Payee_Service updatedPayee = payeeServiceDao.save(existingPayee);
        log.info("Payee updated successfully with ID: {}", payeeAccountId);
        
        return updatedPayee;
    }
    
    /**
     * Get all payees
     */
    @Transactional(readOnly = true)
    public List<Payee_Service> getAllPayees() {
        log.info("Fetching all payees");
        
        List<Payee_Service> payees = payeeServiceDao.findAll();
        log.info("Found {} payee(s)", payees.size());
        
        return payees;
    }
}
package com.NeoBank.Payee_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayeeServiceApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(PayeeServiceApplication.class, args);
        System.out.println("Payee Service Started Successfully");
    }
}
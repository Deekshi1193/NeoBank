package com.NeoBank.Payee_Service.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDateTime;

@Entity
@Table(name = "payee")
public class Payee_Service {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payee_account_id")
    private Long payeeAccountId;
    
    @NotBlank(message = "Payee name is required")
    @Column(name = "payee_name", nullable = false, length = 100)
    private String payeeName;
    
    @NotBlank(message = "Bank name is required")
    @Column(name = "payee_bank_name", nullable = false, length = 100)
    private String payeeBankName;
    
    @NotBlank(message = "IFSC code is required")
    @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "Invalid IFSC code format")
    @Column(name = "ifsc_code", nullable = false, length = 11)
    private String ifscCode;
    
    @NotBlank(message = "Branch address is required")
    @Column(name = "branch_address", nullable = false, length = 255)
    private String branchAddress;
    
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    // Constructors
    public Payee_Service() {
    }
    
    public Payee_Service(Long payeeAccountId, String payeeName, String payeeBankName, 
                        String ifscCode, String branchAddress, LocalDateTime createdAt, 
                        LocalDateTime updatedAt) {
        this.payeeAccountId = payeeAccountId;
        this.payeeName = payeeName;
        this.payeeBankName = payeeBankName;
        this.ifscCode = ifscCode;
        this.branchAddress = branchAddress;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    public Long getPayeeAccountId() {
        return payeeAccountId;
    }
    
    public void setPayeeAccountId(Long payeeAccountId) {
        this.payeeAccountId = payeeAccountId;
    }
    
    public String getPayeeName() {
        return payeeName;
    }
    
    public void setPayeeName(String payeeName) {
        this.payeeName = payeeName;
    }
    
    public String getPayeeBankName() {
        return payeeBankName;
    }
    
    public void setPayeeBankName(String payeeBankName) {
        this.payeeBankName = payeeBankName;
    }
    
    public String getIfscCode() {
        return ifscCode;
    }
    
    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }
    
    public String getBranchAddress() {
        return branchAddress;
    }
    
    public void setBranchAddress(String branchAddress) {
        this.branchAddress = branchAddress;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Lifecycle callbacks
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
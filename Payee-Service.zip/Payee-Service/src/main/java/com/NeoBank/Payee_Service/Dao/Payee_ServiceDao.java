package com.NeoBank.Payee_Service.Dao;

import com.NeoBank.Payee_Service.Model.Payee_Service;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface Payee_ServiceDao extends JpaRepository<Payee_Service, Long> {
    
    // Find payee by account ID
    Optional<Payee_Service> findByPayeeAccountId(Long payeeAccountId);
    
    // Find payees by name (case-insensitive)
    List<Payee_Service> findByPayeeNameContainingIgnoreCase(String payeeName);
    
    // Find payees by IFSC code
    List<Payee_Service> findByIfscCode(String ifscCode);
    
    // Find payees by bank name (case-insensitive)
    List<Payee_Service> findByPayeeBankNameContainingIgnoreCase(String payeeBankName);
    
    // Delete payee by account ID
    void deleteByPayeeAccountId(Long payeeAccountId);
    
    // Delete payees by name
    void deleteByPayeeName(String payeeName);
    
    // Check if payee exists by account ID
    boolean existsByPayeeAccountId(Long payeeAccountId);
    
    // Check if payee exists by name
    boolean existsByPayeeName(String payeeName);
}
package com.NeoBank.Payee_Service.Exception;

// PayeeNotFoundException.java
public class PayeeNotFoundException extends RuntimeException {
    public PayeeNotFoundException(String message) {
        super(message);
    }
}
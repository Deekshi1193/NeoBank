package com.NeoBank.Payee_Service.Model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDateTime;

public class Payee_ServiceDto {
    
    private Long payeeAccountId;
    
    @NotBlank(message = "Payee name is required")
    private String payeeName;
    
    @NotBlank(message = "Bank name is required")
    private String payeeBankName;
    
    @NotBlank(message = "IFSC code is required")
    @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "Invalid IFSC code format (e.g., SBIN0001234)")
    private String ifscCode;
    
    @NotBlank(message = "Branch address is required")
    private String branchAddress;
    
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Constructors
    public Payee_ServiceDto() {
    }
    
    public Payee_ServiceDto(Long payeeAccountId, String payeeName, String payeeBankName, 
                           String ifscCode, String branchAddress, LocalDateTime createdAt, 
                           LocalDateTime updatedAt) {
        this.payeeAccountId = payeeAccountId;
        this.payeeName = payeeName;
        this.payeeBankName = payeeBankName;
        this.ifscCode = ifscCode;
        this.branchAddress = branchAddress;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    public Long getPayeeAccountId() {
        return payeeAccountId;
    }
    
    public void setPayeeAccountId(Long payeeAccountId) {
        this.payeeAccountId = payeeAccountId;
    }
    
    public String getPayeeName() {
        return payeeName;
    }
    
    public void setPayeeName(String payeeName) {
        this.payeeName = payeeName;
    }
    
    public String getPayeeBankName() {
        return payeeBankName;
    }
    
    public void setPayeeBankName(String payeeBankName) {
        this.payeeBankName = payeeBankName;
    }
    
    public String getIfscCode() {
        return ifscCode;
    }
    
    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }
    
    public String getBranchAddress() {
        return branchAddress;
    }
    
    public void setBranchAddress(String branchAddress) {
        this.branchAddress = branchAddress;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
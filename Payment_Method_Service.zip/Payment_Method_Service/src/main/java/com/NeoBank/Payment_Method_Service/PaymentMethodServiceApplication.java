package com.NeoBank.Payment_Method_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentMethodServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentMethodServiceApplication.class, args);
	}

}

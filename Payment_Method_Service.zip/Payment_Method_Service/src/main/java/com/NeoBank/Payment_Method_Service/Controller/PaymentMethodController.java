package com.NeoBank.Payment_Method_Service.Controller;

import com.NeoBank.Payment_Method_Service.Model.PaymentMethodModel;
import com.NeoBank.Payment_Method_Service.Service.PaymentMethodService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/payment-methods")
public class PaymentMethodController {
    
    private static final Logger logger = LoggerFactory.getLogger(PaymentMethodController.class);
    
    @Autowired
    private PaymentMethodService paymentMethodService;
    
    @PostMapping
    public ResponseEntity<Map<String, Object>> addPaymentMethod(@RequestBody PaymentMethodModel model) {
        logger.info("Request received to add payment method: {}", model.getName());
        Map<String, Object> response = new HashMap<>();
        try {
            PaymentMethodModel created = paymentMethodService.addPaymentMethod(model);
            response.put("status", "success");
            response.put("message", "Payment method created successfully");
            response.put("data", created);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            logger.error("Error adding payment method: {}", e.getMessage());
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updatePaymentMethod(
            @PathVariable Long id, 
            @RequestBody PaymentMethodModel model) {
        logger.info("Request received to update payment method with ID: {}", id);
        Map<String, Object> response = new HashMap<>();
        try {
            PaymentMethodModel updated = paymentMethodService.updatePaymentMethod(id, model);
            response.put("status", "success");
            response.put("message", "Payment method updated successfully");
            response.put("data", updated);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error updating payment method: {}", e.getMessage());
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deletePaymentMethodById(@PathVariable Long id) {
        logger.info("Request received to delete payment method with ID: {}", id);
        Map<String, Object> response = new HashMap<>();
        try {
            paymentMethodService.deletePaymentMethodById(id);
            response.put("status", "success");
            response.put("message", "Payment method deleted successfully");
            response.put("data", null);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error deleting payment method: {}", e.getMessage());
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    
    @DeleteMapping("/name/{name}")
    public ResponseEntity<Map<String, Object>> deletePaymentMethodByName(@PathVariable String name) {
        logger.info("Request received to delete payment method with name: {}", name);
        Map<String, Object> response = new HashMap<>();
        try {
            paymentMethodService.deletePaymentMethodByName(name);
            response.put("status", "success");
            response.put("message", "Payment method deleted successfully");
            response.put("data", null);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error deleting payment method: {}", e.getMessage());
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getPaymentMethodById(@PathVariable Long id) {
        logger.info("Request received to fetch payment method with ID: {}", id);
        Map<String, Object> response = new HashMap<>();
        Optional<PaymentMethodModel> method = paymentMethodService.getPaymentMethodById(id);
        if (method.isPresent()) {
            response.put("status", "success");
            response.put("message", "Payment method retrieved successfully");
            response.put("data", method.get());
            return ResponseEntity.ok(response);
        } else {
            logger.warn("Payment method not found with ID: {}", id);
            response.put("status", "error");
            response.put("message", "Payment method not found with ID: " + id);
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    
    @GetMapping("/name/{name}")
    public ResponseEntity<Map<String, Object>> getPaymentMethodByName(@PathVariable String name) {
        logger.info("Request received to fetch payment method with name: {}", name);
        Map<String, Object> response = new HashMap<>();
        Optional<PaymentMethodModel> method = paymentMethodService.getPaymentMethodByName(name);
        if (method.isPresent()) {
            response.put("status", "success");
            response.put("message", "Payment method retrieved successfully");
            response.put("data", method.get());
            return ResponseEntity.ok(response);
        } else {
            logger.warn("Payment method not found with name: {}", name);
            response.put("status", "error");
            response.put("message", "Payment method not found with name: " + name);
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllPaymentMethods() {
        logger.info("Request received to fetch all payment methods");
        Map<String, Object> response = new HashMap<>();
        List<PaymentMethodModel> methods = paymentMethodService.getAllPaymentMethods();
        response.put("status", "success");
        response.put("message", "Payment methods retrieved successfully");
        response.put("data", methods);
        return ResponseEntity.ok(response);
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGlobalException(Exception ex) {
        logger.error("Unexpected error occurred: {}", ex.getMessage());
        Map<String, Object> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", "An unexpected error occurred: " + ex.getMessage());
        response.put("data", null);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}
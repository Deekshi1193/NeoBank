package com.NeoBank.Payment_Method_Service.Dao;

import com.NeoBank.Payment_Method_Service.Model.PaymentMethodModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentMethodDao extends JpaRepository<PaymentMethodModel, Long> {
    
    Optional<PaymentMethodModel> findByName(String name);
    
    boolean existsByName(String name);
    
    void deleteByName(String name);
}
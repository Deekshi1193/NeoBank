package com.NeoBank.Payment_Method_Service.Service;

import com.NeoBank.Payment_Method_Service.Dao.PaymentMethodDao;
import com.NeoBank.Payment_Method_Service.Model.PaymentMethodModel;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentMethodService {
    
    private static final Logger logger = LoggerFactory.getLogger(PaymentMethodService.class);
    
    @Autowired
    private PaymentMethodDao paymentMethodDao;
    
    public PaymentMethodModel addPaymentMethod(PaymentMethodModel model) {
        logger.info("Adding new payment method: {}", model.getName());
        
        if (model.getName() == null || model.getName().trim().isEmpty()) {
            logger.error("Payment method name is required");
            throw new RuntimeException("Payment method name is required");
        }
        
        if (paymentMethodDao.existsByName(model.getName())) {
            logger.error("Payment method already exists: {}", model.getName());
            throw new RuntimeException("Payment method with name '" + model.getName() + "' already exists");
        }
        
        if (model.getIsActive() == null) {
            model.setIsActive(true);
        }
        
        PaymentMethodModel saved = paymentMethodDao.save(model);
        logger.info("Payment method added successfully with ID: {}", saved.getId());
        return saved;
    }
    
    public PaymentMethodModel updatePaymentMethod(Long id, PaymentMethodModel model) {
        logger.info("Updating payment method with ID: {}", id);
        
        PaymentMethodModel existing = paymentMethodDao.findById(id)
                .orElseThrow(() -> {
                    logger.error("Payment method not found with ID: {}", id);
                    return new RuntimeException("Payment method not found with ID: " + id);
                });
        
        if (model.getName() == null || model.getName().trim().isEmpty()) {
            logger.error("Payment method name is required");
            throw new RuntimeException("Payment method name is required");
        }
        
        if (!existing.getName().equals(model.getName()) && paymentMethodDao.existsByName(model.getName())) {
            logger.error("Payment method name already exists: {}", model.getName());
            throw new RuntimeException("Payment method with name '" + model.getName() + "' already exists");
        }
        
        existing.setName(model.getName());
        existing.setDescription(model.getDescription());
        if (model.getIsActive() != null) {
            existing.setIsActive(model.getIsActive());
        }
        
        PaymentMethodModel updated = paymentMethodDao.save(existing);
        logger.info("Payment method updated successfully: {}", updated.getId());
        return updated;
    }
    
    @Transactional
    public void deletePaymentMethodById(Long id) {
        logger.info("Deleting payment method with ID: {}", id);
        
        if (!paymentMethodDao.existsById(id)) {
            logger.error("Payment method not found with ID: {}", id);
            throw new RuntimeException("Payment method not found with ID: " + id);
        }
        
        paymentMethodDao.deleteById(id);
        logger.info("Payment method deleted successfully with ID: {}", id);
    }
    
    @Transactional
    public void deletePaymentMethodByName(String name) {
        logger.info("Deleting payment method with name: {}", name);
        
        if (!paymentMethodDao.existsByName(name)) {
            logger.error("Payment method not found with name: {}", name);
            throw new RuntimeException("Payment method not found with name: " + name);
        }
        
        paymentMethodDao.deleteByName(name);
        logger.info("Payment method deleted successfully with name: {}", name);
    }
    
    public Optional<PaymentMethodModel> getPaymentMethodById(Long id) {
        logger.info("Fetching payment method with ID: {}", id);
        return paymentMethodDao.findById(id);
    }
    
    public Optional<PaymentMethodModel> getPaymentMethodByName(String name) {
        logger.info("Fetching payment method with name: {}", name);
        return paymentMethodDao.findByName(name);
    }
    
    public List<PaymentMethodModel> getAllPaymentMethods() {
        logger.info("Fetching all payment methods");
        return paymentMethodDao.findAll();
    }
}
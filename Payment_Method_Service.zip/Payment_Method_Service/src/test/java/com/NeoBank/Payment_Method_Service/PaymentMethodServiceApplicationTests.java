package com.NeoBank.Payment_Method_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMethodServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
